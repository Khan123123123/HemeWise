# HemeWise Diagnostic Engine

**AI-Powered Hematology Decision Support System**

Based on *HemeWise: High Yield Hematology Charts* by Dr. Sahrish Bari (2025)

---

## 🎯 Overview

The HemeWise Diagnostic Engine transforms a comprehensive 29-page hematology reference guide into a structured, executable diagnostic system. Every algorithm, decision tree, and clinical parameter has been encoded into JSON-based knowledge bases with full source traceability.

## 📁 Project Structure

```
hemewise_engine/
├── data/                          # Knowledge bases (23 JSON files)
│   ├── anemia_diagnostic_tables.json
│   ├── bone_marrow_failure.json
│   ├── coagulation_disorders.json
│   ├── flow_cytometry_logic.json
│   ├── hemolytic_anemia_logic.json
│   ├── hodgkin_lymphoma.json
│   ├── leukemia_mimics.json
│   ├── leukemia_profiles.json
│   ├── macrocytic_anemia_logic.json
│   ├── marker_disease_knowledge_graph.json
│   ├── mds_logic.json
│   ├── microcytic_anemia_logic.json
│   ├── mpn_logic.json
│   ├── mutation_tracker.json
│   ├── nhl_b_cell.json
│   ├── nhl_t_cell.json
│   ├── pancytopenia_logic.json
│   ├── plasma_cell_disorders.json
│   ├── platelet_disorders.json
│   ├── thrombophilia.json
│   ├── tma_maha_differential.json
│   └── transfusion_reactions.json
│
├── logic/                         # Decision algorithms
│   ├── pancytopenia_algorithm.json
│   ├── flow_cytometry_decision_tree.json
│   └── differential_diagnosis_scoring.json
│
├── logic_trees/                   # Executable decision trees
│   ├── pancytopenia_decision_tree.json
│   ├── flow_cytometry_decision_tree.json
│   └── leukemia_decision_tree.json
│
├── knowledge_graph/               # Marker-disease relationships
│   └── marker_disease_relationships.json
│
├── schemas/                       # Data schemas
│   └── master_schema.json
│
└── api/                           # API layer
    ├── endpoints.json
    ├── monetization_framework.json
    └── hemewise_engine.js
```

## 🚨 Critical Alert System

The engine includes built-in detection for hematologic emergencies:

| Condition | Trigger | Action |
|-----------|---------|--------|
| **APL** | Faggot cells, t(15;17) | START ATRA IMMEDIATELY |
| **TTP** | ADAMTS13 <10%, schistocytes | URGENT PLASMAPHERESIS |
| **HLH** | Ferritin >10,000, cytopenias | Urgent heme consult |
| **DIC** | Low fibrinogen, elevated D-dimer | Treat underlying cause |
| **TLS** | Hyperuricemia, hyperkalemia | Rasburicase, hydration |

## 📊 Data Coverage

### Diagnostic Algorithms
- Pancytopenia stepwise workup (Page 5)
- Flow cytometry decision tree (Pages 3, 4, 26)
- Leukemia look-alikes scoring (Page 24)

### Anemia Classification
- Microcytic anemias (10 entities) - Page 6
- Macrocytic anemias (8 entities) - Page 7
- Hemolytic anemias - Page 8
- TMA/MAHA differential - Page 9

### Hematologic Malignancies
- Acute leukemias (AML, ALL) - Page 14
- Chronic leukemias (CML, CLL) - Page 14
- Rare/aggressive leukemias - Page 18
- Hodgkin lymphoma - Page 19
- NHL B-cell subtypes - Page 20
- NHL T-cell subtypes - Pages 21-22
- Plasma cell disorders - Page 23

### Coagulation & Platelets
- Platelet disorders - Page 10
- Coagulation disorders - Pages 11-12
- Thrombophilia panel - Page 13

### Bone Marrow
- Bone marrow failure syndromes - Page 15
- MPNs (ET, PV, PMF) - Page 16
- MDS subtypes - Page 17

### Molecular & Markers
- Mutation tracker (JAK2, CALR, FLT3, NPM1, etc.) - Page 25
- Flow cytometry marker panels - Pages 3, 4, 26
- Marker-disease knowledge graph

### Transfusion
- Transfusion reactions - Pages 27-28

## 💰 Monetization Tiers

### 1. HemeWise Lite (Free)
- Basic CBC interpretation
- Anemia classifier
- Buzzword lookup
- 10 queries/day

### 2. HemeWise Pro ($29/month)
- Full diagnostic algorithms
- Flow cytometry analyzer
- Pancytopenia workup
- PDF report generation
- 100 queries/day

### 3. HemeWise Board-Prep ($19/month)
- AI-generated clinical vignettes
- FCPS/IMM/USMLE question bank
- Buzzword-based flashcards
- Exam trap explanations

### 4. HemeWise Institutional ($2,999/year)
- EHR integration (HL7/FHIR)
- Real-time red flag alerts
- Batch patient analysis
- HIPAA compliance
- Custom alert thresholds

### 5. HemeWise Quick-Consult ($39/month)
- Natural language queries
- Bedside decision support
- Transfusion advisor
- Mobile app (iOS/Android)

## 🔧 Technical Integration

### API Usage Example

```javascript
const HemeWiseEngine = require('./api/hemewise_engine');

const engine = new HemeWiseEngine();

// Analyze CBC
const cbcResult = engine.classifyAnemia({
  hemoglobin: 8.5,
  mcv: 68,
  rdw: 18,
  ferritin: 8,
  transferrin_sat: 12
});

// Check for critical conditions
const alerts = engine.checkCriticalConditions({
  platelet: 25,
  adamts13: 5,
  smearFindings: ['schistocytes']
});

// Run pancytopenia algorithm
const pancyto = engine.evaluatePancytopenia({
  hemoglobin: 7.2,
  wbc: 2.1,
  platelet: 45,
  reticulocyte_count: 0.5
});

// Analyze flow cytometry
const flow = engine.analyzeFlowCytometry({
  CD34: '+',
  CD117: '+',
  CD13: '+',
  CD33: '+',
  MPO: '+',
  'HLA-DR': '+',
  CD19: '-'
}, 45); // blast %
```

### EHR Integration

```json
POST /api/v1/hemewise/ehr/red-flags
{
  "patient_id": "12345",
  "lab_results": {
    "cbc": {
      "wbc": 85.0,
      "hemoglobin": 6.5,
      "platelet": 12
    },
    "special_hematology": {
      "blast_percentage": 65,
      "smear_findings": ["faggot_cells"]
    }
  }
}

Response:
{
  "alerts": [{
    "severity": "CRITICAL",
    "finding": "Faggot cells with blasts",
    "suspected_condition": "APL",
    "recommended_action": "START ATRA IMMEDIATELY",
    "time_sensitivity": "MINUTES",
    "notify": ["Hematology", "Pharmacy", "ICU"]
  }]
}
```

## ✅ Classification Standards

- WHO 2022 Classification
- ICC 2022 Guidelines
- IPSS-R for MDS
- ELN 2022 for AML

## ⚠️ Disclaimer

This tool is for **educational and clinical decision support only**. All diagnostic and therapeutic decisions must be made by qualified healthcare professionals. This system does not replace clinical judgment, physical examination, or consultation with specialists.

## 📚 Source Attribution

All content derived from:
> **HemeWise: High Yield Hematology Charts**  
> by Dr. Sahrish Bari (2025)  
> All rights reserved.

---

## 🚀 Quick Start

1. Clone the repository
2. Install dependencies: `npm install`
3. Run the engine: `node api/hemewise_engine.js`
4. Access API at `http://localhost:3000/api/v1/hemewise`

## 📈 Roadmap

- [ ] Phase 1: Board-Prep launch (FCPS Pakistan)
- [ ] Phase 2: Pro tier + Middle East expansion
- [ ] Phase 3: Mobile app + US market entry
- [ ] Phase 4: Enterprise EHR integrations

---

*Built with ❤️ for the hematology community*
