/**
 * HemeWise Diagnostic Engine - Core Module
 * Based on HemeWise: High Yield Hematology Charts by Dr. Sahrish Bari (2025)
 * 
 * This module provides the core diagnostic logic for:
 * - CBC interpretation
 * - Anemia classification
 * - Pancytopenia workup
 * - Flow cytometry analysis
 * - Critical alert detection
 */

class HemeWiseEngine {
  constructor(dataPath = './data') {
    this.dataPath = dataPath;
    this.criticalAlerts = [];
    this.DISCLAIMER = `This tool is for educational and clinical decision support only. 
All diagnostic decisions must be made by qualified healthcare professionals.`;
  }

  // ============================================================
  // CRITICAL ALERT SYSTEM
  // ============================================================
  
  checkCriticalConditions(labData, smearFindings = []) {
    const alerts = [];
    
    // APL Emergency
    if (smearFindings.includes('faggot_cells') || 
        smearFindings.includes('auer_rods') ||
        labData.cytogenetics?.includes('t(15;17)') ||
        labData.fish?.includes('PML-RARA')) {
      alerts.push({
        condition: 'APL_EMERGENCY',
        severity: 'CRITICAL',
        action: 'START ATRA IMMEDIATELY - Do not wait for confirmation',
        timeframe: 'MINUTES',
        notify: ['Hematology', 'Pharmacy', 'ICU'],
        source_page: 4
      });
    }
    
    // TTP Emergency
    if (labData.adamts13 !== undefined && labData.adamts13 < 10 &&
        smearFindings.includes('schistocytes') &&
        labData.platelet < 100) {
      alerts.push({
        condition: 'TTP_EMERGENCY',
        severity: 'CRITICAL',
        action: 'URGENT PLASMAPHERESIS - Contact blood bank immediately',
        timeframe: 'HOURS',
        notify: ['Hematology', 'Blood Bank', 'Nephrology'],
        source_page: 9
      });
    }
    
    // HLH Possible
    if (labData.ferritin > 10000 &&
        labData.platelet < 100 &&
        (labData.splenomegaly || smearFindings.includes('hemophagocytosis'))) {
      alerts.push({
        condition: 'HLH_POSSIBLE',
        severity: 'URGENT',
        action: 'Check HLH criteria - Consider bone marrow, soluble CD25, NK function',
        timeframe: 'SAME_DAY',
        notify: ['Hematology', 'Rheumatology'],
        source_page: 5
      });
    }
    
    // DIC
    if (labData.pt > 16 && labData.ptt > 40 &&
        labData.fibrinogen < 150 && labData.d_dimer > 4 &&
        smearFindings.includes('schistocytes')) {
      alerts.push({
        condition: 'DIC',
        severity: 'CRITICAL',
        action: 'TREAT UNDERLYING CAUSE - Supportive care with FFP/cryo/platelets',
        timeframe: 'IMMEDIATE',
        notify: ['Hematology', 'ICU'],
        source_page: 12
      });
    }
    
    // Tumor Lysis Syndrome
    if (labData.uric_acid > 8 && labData.potassium > 6 &&
        labData.phosphorus > 6.5 && labData.calcium < 7) {
      alerts.push({
        condition: 'TUMOR_LYSIS_SYNDROME',
        severity: 'CRITICAL',
        action: 'AGGRESSIVE HYDRATION + RASBURICASE - Monitor cardiac rhythm',
        timeframe: 'IMMEDIATE',
        notify: ['Oncology', 'Nephrology', 'ICU'],
        source_page: 18
      });
    }
    
    // Acute Leukemia
    if (labData.blast_percentage > 20) {
      alerts.push({
        condition: 'ACUTE_LEUKEMIA',
        severity: 'URGENT',
        action: 'Urgent flow cytometry + cytogenetics + molecular studies',
        timeframe: 'SAME_DAY',
        notify: ['Hematology', 'Pathology'],
        source_page: 14
      });
    }
    
    return alerts;
  }

  // ============================================================
  // ANEMIA CLASSIFICATION
  // ============================================================
  
  classifyAnemia(labData) {
    const { hemoglobin, mcv, rdw, ferritin, serum_iron, tibc, 
            transferrin_sat, reticulocyte_count, ldh, haptoglobin,
            bilirubin_indirect, b12_level, folate_level } = labData;
    
    // Check if anemia present
    if (hemoglobin >= 12) {
      return { anemia: false, message: 'Hemoglobin within normal range' };
    }
    
    let result = {
      anemia: true,
      hemoglobin,
      severity: this.classifyAnemiaSeverity(hemoglobin),
      mcv_category: null,
      differential: [],
      recommended_tests: [],
      source_pages: []
    };
    
    // MCV-based classification
    if (mcv < 80) {
      result.mcv_category = 'microcytic';
      result.source_pages.push(6);
      result.differential = this.getMicrocyticDifferential(labData);
    } else if (mcv > 100) {
      result.mcv_category = 'macrocytic';
      result.source_pages.push(7);
      result.differential = this.getMacrocyticDifferential(labData);
    } else {
      result.mcv_category = 'normocytic';
      result.differential = this.getNormocyticDifferential(labData);
    }
    
    // Check for hemolysis
    if (reticulocyte_count > 2 || ldh > 250 || 
        haptoglobin < 30 || bilirubin_indirect > 1.2) {
      result.hemolysis_markers = {
        present: true,
        evidence: []
      };
      if (reticulocyte_count > 2) result.hemolysis_markers.evidence.push('Elevated reticulocytes');
      if (ldh > 250) result.hemolysis_markers.evidence.push('Elevated LDH');
      if (haptoglobin < 30) result.hemolysis_markers.evidence.push('Low haptoglobin');
      if (bilirubin_indirect > 1.2) result.hemolysis_markers.evidence.push('Elevated indirect bilirubin');
      result.source_pages.push(8);
    }
    
    return result;
  }
  
  classifyAnemiaSeverity(hb) {
    if (hb < 7) return 'severe';
    if (hb < 10) return 'moderate';
    return 'mild';
  }
  
  getMicrocyticDifferential(labData) {
    const { ferritin, transferrin_sat, rdw } = labData;
    const differential = [];
    
    // Iron Deficiency Anemia
    if (ferritin < 30 || transferrin_sat < 20) {
      differential.push({
        diagnosis: 'Iron Deficiency Anemia',
        confidence: ferritin < 15 ? 95 : 75,
        supporting_features: ['Low ferritin', 'Low transferrin saturation', 'High RDW'],
        buzzwords: ['Pica', 'Koilonychia', 'Angular cheilitis'],
        management: 'Oral iron 325mg TID, investigate GI source if male or postmenopausal',
        source_page: 6
      });
    }
    
    // Thalassemia Trait
    if (rdw < 15 && ferritin >= 30) {
      differential.push({
        diagnosis: 'Thalassemia Trait',
        confidence: 70,
        supporting_features: ['Normal/low RDW', 'Normal ferritin', 'Ethnic background'],
        buzzwords: ['Mentzer index < 13', 'Target cells', 'Basophilic stippling'],
        confirmatory_test: 'Hemoglobin electrophoresis',
        source_page: 6
      });
    }
    
    // Anemia of Chronic Disease
    if (ferritin > 100 && transferrin_sat < 20) {
      differential.push({
        diagnosis: 'Anemia of Chronic Disease',
        confidence: 65,
        supporting_features: ['Normal/high ferritin', 'Low transferrin sat', 'Underlying inflammation'],
        buzzwords: ['Hepcidin elevation', 'Functional iron deficiency'],
        source_page: 6
      });
    }
    
    // Sideroblastic Anemia
    differential.push({
      diagnosis: 'Sideroblastic Anemia',
      confidence: 20,
      supporting_features: ['Dimorphic RBC population', 'Pappenheimer bodies'],
      buzzwords: ['Ring sideroblasts', 'B6 deficiency', 'Lead poisoning'],
      confirmatory_test: 'Bone marrow with iron stain',
      source_page: 6
    });
    
    return differential.sort((a, b) => b.confidence - a.confidence);
  }
  
  getMacrocyticDifferential(labData) {
    const { b12_level, folate_level, reticulocyte_count } = labData;
    const differential = [];
    
    // B12 Deficiency
    if (b12_level < 200) {
      differential.push({
        diagnosis: 'Vitamin B12 Deficiency',
        confidence: 90,
        supporting_features: ['Low B12', 'Hypersegmented neutrophils', 'Neurological symptoms'],
        buzzwords: ['Subacute combined degeneration', 'Glossitis', 'Methylmalonic acid elevated'],
        management: 'B12 1000mcg IM daily x7, then weekly x4, then monthly',
        source_page: 7
      });
    }
    
    // Folate Deficiency
    if (folate_level < 3) {
      differential.push({
        diagnosis: 'Folate Deficiency',
        confidence: 85,
        supporting_features: ['Low folate', 'Hypersegmented neutrophils', 'No neurological symptoms'],
        buzzwords: ['Alcoholism', 'Pregnancy', 'Methotrexate'],
        management: 'Folate 1-5mg daily',
        source_page: 7
      });
    }
    
    // MDS
    differential.push({
      diagnosis: 'Myelodysplastic Syndrome',
      confidence: 30,
      supporting_features: ['Older age', 'Cytopenias', 'Dysplastic features on smear'],
      buzzwords: ['Pseudo-Pelger-Huet', 'Ring sideroblasts', 'Hypogranular neutrophils'],
      confirmatory_test: 'Bone marrow biopsy with cytogenetics',
      source_page: 17
    });
    
    // Reticulocytosis
    if (reticulocyte_count > 3) {
      differential.push({
        diagnosis: 'Reticulocytosis (Hemolysis/Hemorrhage recovery)',
        confidence: 80,
        supporting_features: ['Elevated reticulocytes', 'Polychromasia'],
        management: 'Evaluate for hemolysis vs. bleeding recovery',
        source_page: 7
      });
    }
    
    // Drug-induced
    differential.push({
      diagnosis: 'Drug-Induced Macrocytosis',
      confidence: 25,
      supporting_features: ['Medication history positive'],
      buzzwords: ['Methotrexate', 'Hydroxyurea', 'Azathioprine', 'AZT', 'Phenytoin'],
      source_page: 7
    });
    
    return differential.sort((a, b) => b.confidence - a.confidence);
  }
  
  getNormocyticDifferential(labData) {
    return [
      { diagnosis: 'Anemia of Chronic Disease', confidence: 40 },
      { diagnosis: 'Early Iron Deficiency', confidence: 25 },
      { diagnosis: 'Chronic Kidney Disease', confidence: 25 },
      { diagnosis: 'Mixed Deficiency', confidence: 10 }
    ];
  }

  // ============================================================
  // PANCYTOPENIA ALGORITHM
  // ============================================================
  
  evaluatePancytopenia(labData, clinicalData = {}) {
    const steps = [];
    let currentStep = 1;
    
    // Step 1: Confirm pancytopenia
    if (labData.hemoglobin < 10 && labData.wbc < 4 && labData.platelet < 150) {
      steps.push({
        step: currentStep++,
        action: 'Pancytopenia confirmed',
        findings: {
          hemoglobin: labData.hemoglobin,
          wbc: labData.wbc,
          platelet: labData.platelet
        }
      });
    } else {
      return {
        pancytopenia: false,
        message: 'Does not meet criteria for pancytopenia',
        criteria: 'Hb <10, WBC <4, Plt <150'
      };
    }
    
    // Step 2: Review smear
    steps.push({
      step: currentStep++,
      action: 'Review peripheral blood smear',
      look_for: ['Blasts', 'Dysplastic cells', 'Schistocytes', 'Abnormal lymphocytes', 'Faggot cells'],
      critical_alert: 'If faggot cells seen → APL emergency'
    });
    
    // Step 3: Check reticulocytes
    const reticDecision = labData.reticulocyte_count > 2 ? 'hyperproliferative' : 'hypoproliferative';
    steps.push({
      step: currentStep++,
      action: 'Check reticulocyte count',
      result: `${labData.reticulocyte_count}% - ${reticDecision}`,
      interpretation: reticDecision === 'hyperproliferative' ? 
        'Consider: Hemolysis, Hypersplenism, Immune destruction' :
        'Consider: Bone marrow failure, Infiltration, Aplasia'
    });
    
    // Step 4: Check for hemolysis
    if (labData.ldh > 250 || labData.haptoglobin < 30) {
      steps.push({
        step: currentStep++,
        action: 'Hemolysis workup positive',
        consider: ['TTP/HUS', 'Evans syndrome', 'DIC', 'PNH'],
        order: ['Direct Coombs', 'Flow for PNH', 'ADAMTS13 if schistocytes']
      });
    }
    
    // Step 5: Check B12/Folate
    if (labData.mcv > 100 || labData.b12_level < 300 || labData.folate_level < 5) {
      steps.push({
        step: currentStep++,
        action: 'Check B12/Folate',
        result: labData.b12_level < 200 ? 'B12 deficiency likely' : 
                labData.folate_level < 3 ? 'Folate deficiency likely' : 'Within range'
      });
    }
    
    // Step 6: Medications
    steps.push({
      step: currentStep++,
      action: 'Review medication history',
      high_risk_meds: [
        'Chemotherapy', 'Methotrexate', 'Azathioprine', 'TMP-SMX',
        'Carbimazole', 'NSAIDs', 'Gold', 'Penicillamine'
      ]
    });
    
    // Step 7: Infections
    steps.push({
      step: currentStep++,
      action: 'Rule out infections',
      order: ['HIV', 'Hepatitis B/C', 'EBV/CMV', 'Parvovirus B19'],
      consider: ['TB', 'Leishmaniasis', 'Brucellosis'] 
    });
    
    // Step 8: Bone marrow
    steps.push({
      step: currentStep++,
      action: 'Bone marrow biopsy indicated',
      send_for: [
        'Morphology',
        'Iron stain',
        'Flow cytometry',
        'Cytogenetics',
        'Molecular studies'
      ],
      look_for: [
        'Hypocellularity (aplastic anemia)',
        'Infiltration (malignancy, fibrosis)',
        'Dysplasia (MDS)',
        'Blasts (acute leukemia)',
        'Hemophagocytosis (HLH)'
      ]
    });
    
    return {
      pancytopenia: true,
      algorithm_steps: steps,
      likely_categories: this.categorizePancytopenia(labData, clinicalData),
      source_page: 5
    };
  }
  
  categorizePancytopenia(labData, clinicalData) {
    const categories = [];
    
    if (clinicalData.splenomegaly) {
      categories.push({
        category: 'Hypersplenism',
        likelihood: 'high',
        features: ['Splenomegaly present']
      });
    }
    
    if (labData.mcv > 100) {
      categories.push({
        category: 'Megaloblastic',
        likelihood: 'moderate',
        features: ['Macrocytosis']
      });
    }
    
    if (clinicalData.age > 60) {
      categories.push({
        category: 'MDS/Malignancy',
        likelihood: 'moderate',
        features: ['Age > 60']
      });
    }
    
    return categories;
  }

  // ============================================================
  // FLOW CYTOMETRY ANALYSIS
  // ============================================================
  
  analyzeFlowCytometry(markers, blastPercentage = null) {
    const result = {
      lineage: null,
      classification: null,
      confidence: 0,
      supporting_markers: [],
      aberrant_markers: [],
      who_2022_category: null,
      source_pages: [3, 4, 26]
    };
    
    // Check CD34 (blast marker)
    const isCD34Positive = markers.CD34 === '+' || markers.CD34 === 'bright';
    
    // Myeloid markers
    const myeloidMarkers = ['CD13', 'CD33', 'CD117', 'MPO', 'CD15', 'CD14', 'CD64'];
    const myeloidPositive = myeloidMarkers.filter(m => markers[m] === '+' || markers[m] === 'bright');
    
    // B-lymphoid markers
    const bMarkers = ['CD19', 'CD10', 'CD20', 'CD22', 'CD79a', 'cCD22'];
    const bPositive = bMarkers.filter(m => markers[m] === '+' || markers[m] === 'bright');
    
    // T-lymphoid markers
    const tMarkers = ['CD3', 'CD5', 'CD7', 'cCD3', 'CD2', 'CD4', 'CD8'];
    const tPositive = tMarkers.filter(m => markers[m] === '+' || markers[m] === 'bright');
    
    // Classify lineage
    if (myeloidPositive.length >= 2 && (markers.MPO === '+' || myeloidPositive.length >= 3)) {
      result.lineage = 'myeloid';
      result.supporting_markers = myeloidPositive;
      
      if (blastPercentage >= 20) {
        result.classification = 'AML';
        result.who_2022_category = 'AML, NOS (pending cytogenetics/molecular)';
      }
      
      // Check for APL
      if (markers.CD34 === '-' && markers['HLA-DR'] === '-') {
        result.classification = 'APL_SUSPECT';
        result.who_2022_category = 'APL - CONFIRM WITH FISH FOR PML-RARA';
        result.critical_alert = {
          condition: 'APL_POSSIBLE',
          action: 'START ATRA if clinical suspicion high',
          markers: 'CD34-/HLA-DR- myeloid blasts'
        };
      }
    } else if (bPositive.length >= 2) {
      result.lineage = 'B-lymphoid';
      result.supporting_markers = bPositive;
      
      if (blastPercentage >= 20 || markers.TdT === '+') {
        result.classification = 'B-ALL';
        result.who_2022_category = 'B-ALL, NOS (pending cytogenetics)';
      } else {
        // Mature B-cell neoplasm
        result.classification = this.classifyMatureBCell(markers);
      }
    } else if (tPositive.length >= 2) {
      result.lineage = 'T-lymphoid';
      result.supporting_markers = tPositive;
      
      if (markers.TdT === '+' || markers.CD1a === '+') {
        result.classification = 'T-ALL';
        result.who_2022_category = 'T-ALL/LBL';
      } else {
        result.classification = this.classifyMatureTCell(markers);
      }
    }
    
    // Check for MPAL
    const lineageCount = [myeloidPositive.length >= 2, bPositive.length >= 2, tPositive.length >= 2]
      .filter(Boolean).length;
    if (lineageCount >= 2) {
      result.lineage = 'MPAL';
      result.classification = 'Mixed Phenotype Acute Leukemia';
      result.who_2022_category = 'MPAL - requires WHO 2022 criteria confirmation';
    }
    
    // Detect aberrant markers
    if (result.lineage === 'myeloid') {
      result.aberrant_markers = bPositive.concat(tPositive);
    } else if (result.lineage === 'B-lymphoid') {
      result.aberrant_markers = myeloidPositive.concat(tPositive);
    } else if (result.lineage === 'T-lymphoid') {
      result.aberrant_markers = myeloidPositive.concat(bPositive);
    }
    
    // Calculate confidence
    result.confidence = Math.min(95, result.supporting_markers.length * 15 + 
      (blastPercentage >= 20 ? 20 : 0));
    
    return result;
  }
  
  classifyMatureBCell(markers) {
    // CLL/SLL
    if (markers.CD5 === '+' && markers.CD23 === '+' && markers.CD200 === '+') {
      return {
        diagnosis: 'CLL/SLL',
        confidence: 90,
        characteristic: 'CD5+/CD23+/CD200+ B-cells',
        source_page: 20
      };
    }
    
    // Mantle Cell Lymphoma
    if (markers.CD5 === '+' && markers.CD23 === '-' && markers.cyclinD1 === '+') {
      return {
        diagnosis: 'Mantle Cell Lymphoma',
        confidence: 95,
        characteristic: 'CD5+/CD23-/Cyclin D1+',
        confirmatory: 't(11;14)',
        source_page: 20
      };
    }
    
    // Hairy Cell Leukemia
    if (markers.CD11c === '+' && markers.CD25 === '+' && markers.CD103 === '+') {
      return {
        diagnosis: 'Hairy Cell Leukemia',
        confidence: 95,
        characteristic: 'CD11c+/CD25+/CD103+ triad',
        buzzword: 'Fried egg appearance',
        source_page: 20
      };
    }
    
    // Follicular Lymphoma
    if (markers.CD10 === '+' && markers.BCL6 === '+') {
      return {
        diagnosis: 'Follicular Lymphoma',
        confidence: 75,
        characteristic: 'CD10+/BCL6+ germinal center phenotype',
        confirmatory: 't(14;18)',
        source_page: 20
      };
    }
    
    return { diagnosis: 'B-cell neoplasm, NOS', confidence: 40 };
  }
  
  classifyMatureTCell(markers) {
    // Sézary Syndrome
    if (markers.CD4 === '+' && markers.CD7 === '-' && markers.CD26 === '-') {
      return {
        diagnosis: 'Sézary Syndrome',
        confidence: 80,
        characteristic: 'CD4+/CD7-/CD26- with erythroderma',
        source_page: 22
      };
    }
    
    // T-PLL
    if (markers.CD4 === '+' && markers.CD8 === '-' && markers.CD7 === 'bright') {
      return {
        diagnosis: 'T-PLL',
        confidence: 70,
        characteristic: 'CD4+/CD7bright/CD52+',
        source_page: 21
      };
    }
    
    return { diagnosis: 'T-cell neoplasm, NOS', confidence: 40 };
  }

  // ============================================================
  // DIFFERENTIAL DIAGNOSIS SCORING
  // ============================================================
  
  scoreLeukemiaMimics(labData, clinicalData, smearFindings) {
    const mimics = [];
    
    // Leukemoid Reaction
    let leukemoidScore = 0;
    if (clinicalData.infection) leukemoidScore += 30;
    if (smearFindings.includes('toxic_granulation')) leukemoidScore += 25;
    if (smearFindings.includes('dohle_bodies')) leukemoidScore += 20;
    if (labData.lap_score > 100) leukemoidScore += 25;
    if (!smearFindings.includes('basophilia')) leukemoidScore += 10;
    mimics.push({
      condition: 'Leukemoid Reaction',
      score: leukemoidScore,
      features: ['Infection', 'Toxic granulation', 'Döhle bodies', 'High LAP score'],
      differentiating_test: 'LAP score, BCR-ABL negative',
      source_page: 24
    });
    
    // EBV/Infectious Mononucleosis
    let ebvScore = 0;
    if (clinicalData.pharyngitis) ebvScore += 20;
    if (clinicalData.lymphadenopathy) ebvScore += 20;
    if (smearFindings.includes('atypical_lymphocytes')) ebvScore += 30;
    if (clinicalData.age < 30) ebvScore += 15;
    if (labData.wbc > 10 && labData.wbc < 30) ebvScore += 15;
    mimics.push({
      condition: 'EBV/Infectious Mononucleosis',
      score: ebvScore,
      features: ['Atypical lymphocytes', 'Pharyngitis', 'LAD', 'Young age'],
      differentiating_test: 'Monospot, EBV serology',
      source_page: 24
    });
    
    // B12/Folate Deficiency
    let b12Score = 0;
    if (labData.mcv > 100) b12Score += 25;
    if (smearFindings.includes('hypersegmented_neutrophils')) b12Score += 30;
    if (smearFindings.includes('macro_ovalocytes')) b12Score += 20;
    if (labData.ldh > 250) b12Score += 15;
    mimics.push({
      condition: 'Megaloblastic Anemia',
      score: b12Score,
      features: ['Hypersegmented neutrophils', 'Macro-ovalocytes', 'High LDH'],
      differentiating_test: 'B12, folate, MMA, homocysteine',
      dont_miss: 'Can present with pancytopenia mimicking MDS',
      source_page: 24
    });
    
    // Sort by score
    return mimics.sort((a, b) => b.score - a.score);
  }

  // ============================================================
  // UTILITY METHODS
  // ============================================================
  
  generateReport(analysisResult) {
    return {
      timestamp: new Date().toISOString(),
      analysis: analysisResult,
      critical_alerts: this.criticalAlerts,
      disclaimer: this.DISCLAIMER,
      source: 'HemeWise: High Yield Hematology Charts by Dr. Sahrish Bari (2025)'
    };
  }
}

// Export for use in Node.js or as ES module
if (typeof module !== 'undefined' && module.exports) {
  module.exports = HemeWiseEngine;
}
